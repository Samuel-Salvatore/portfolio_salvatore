﻿/*
 * Created by SharpDevelop.
 * User: samuel.salvatore_ist
 * Date: 03/05/2023
 * Time: 13:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace codice_salvatore
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
		void Button1Click(object sender, EventArgs e)
		{
			
			string data = dateTimePicker1.Text;
            string gen = comboBox1.Text;
            string com = textBox6.Text;
			string cognome = textBox5.Text;

			string vocali = "";
			string consonanti = "";
			string codice_cog = "";
			foreach (char lettere in cognome)
			{

					if ("bcdfghjklmnpqrstvwxyz".Contains(lettere.ToString()))
					{
						consonanti += lettere;

					}
					else
					{
						vocali += lettere;
					}
			}
			if(consonanti.Length >= 3)
			{
				codice_cog = consonanti[0].ToString() + consonanti[1].ToString() + consonanti[2].ToString();
			}
			else if(consonanti.Length == 2)
			{
				codice_cog = consonanti + vocali[0];
			}
			else if(consonanti.Length == 1)
			{
				
				try {
					codice_cog = consonanti + vocali[0] + vocali[1];
				} catch {
					codice_cog = consonanti + vocali[0] + "X";
				}
				
			}
			string nome = textBox4.Text;
			vocali = "";
			consonanti = "";
			string codice_nom = "";
			foreach (char lettere in nome)
			{

				if ("bcdfghjklmnpqrstvwxyz".Contains(lettere.ToString()))
				{
					consonanti += lettere;
				}
				else
				{
					vocali += lettere;
				}
			}
			if(consonanti.Length > 3)
			{
				codice_nom = consonanti[0].ToString() + consonanti[2].ToString() + consonanti[3].ToString();
			}
			else if(consonanti.Length == 3)
			{
				codice_nom = consonanti;
			}
			else if(consonanti.Length == 2)
			{
				codice_nom = consonanti + vocali[0];
			}
			else if(consonanti.Length == 1)
			{
				
				try {
					codice_nom = consonanti + vocali[0] + vocali[1];
				} catch {
					codice_nom = consonanti + vocali[0] + "X";
				}
				
			}

			label8.Text = codice_cog.ToUpper() + codice_nom.ToUpper();
			
			data = data.ToUpper();
            string[] data_sp = data.Split('/');
            int cont = 0;
            int c = 0;
            foreach (char l in data_sp[2])
                
            {
                
                if (cont < 2)
                {
                    
                    if (c == 2 || c == 3)
                    {
                        label8.Text = label8.Text + l;
                        cont++;
                    }
                        
                }
                c++;
            }
            
            

            
            
            
            cont = 0;
            c = 0;
            
            string path = @"mesi.txt";
            
            while (!File.Exists(path))
            {
                using (StreamWriter sw = File.CreateText(path))
                {}
            }
            
            
            using (StreamReader sr = File.OpenText(path))
            {
                string s = " ";
                
                while ((s = sr.ReadLine()) != null)
                {
                    string[] riga = s.Split(',');
                    
                    string mese = riga[0];
                    string l_mese = riga[1];
                    
                    if (data_sp[1] == mese)
                    {
                        label8.Text = label8.Text + l_mese;
                    }
                }
            }

            
            if (gen == "Maschio")
            {
                int num = Int32.Parse(data_sp[0]);
                if (num >= 0 && num <= 9)
                {
                    data_sp[1] = 0 + data_sp[0];
                    label8.Text += data_sp[0];
                }
                else
                {
                	label8.Text += data_sp[0];
                }
                
                
            }
            else if (gen == "Femmina")
            {
                int num = Int32.Parse(data_sp[0]);
                num = num + 40;
                label8.Text = label8.Text + num;
            }
            

            
            path = @"comuni.txt";
            
            while (!File.Exists(path))
            {
                using (StreamWriter sw = File.CreateText(path))
                {}
            }
            
            
            using (StreamReader sr = File.OpenText(path))
            {
                string s = " ";
                
                while ((s = sr.ReadLine()) != null)
                {
                    com = com.ToUpper();
                    string[] riga_com = s.Split('	');
                    
                    
                    string numero = riga_com[0];
                    string cmn = riga_com[1];
                    
                    if (com == cmn)
                    {
                        label8.Text = label8.Text + numero;
                    }
                }
                
            }
            

   
   string cod_fis = label8.Text;
   c = 0;
   string pari = "";
   string disp = "";
   cont = 1;
   
   foreach (char let in cod_fis)
   {
    if ((c%2) != 0)
    {
     pari = pari + let;
    }
    else
    {
     disp = disp + let;
    }
     
    c++;
   }
   

   
   string v_pari, l_pari;
   int val_pari;
   
   path = @"num_pari.txt";
   
   while (!File.Exists(path))
   {
    using (StreamWriter sw = File.CreateText(path))
    {}
   }
   int somma_pa = 0;
   foreach (char l in pari)
   {
    string lettera = l.ToString();
     
    using (StreamReader sr = File.OpenText(path))
    {
     string s = " ";
     
     while ((s = sr.ReadLine()) != null)
     {
      
      string[] riga = s.Split(',');
      
      
      l_pari = riga[0];
      v_pari = riga[1];
      
      val_pari = Int32.Parse(v_pari);
      
      if (lettera == l_pari)
      {
       somma_pa = somma_pa + val_pari;
      }
     }
     
    }
   }
   
   

   
 
   path = @"num_disp.txt";
   
   while (!File.Exists(path))
   {
    using (StreamWriter sw = File.CreateText(path))
    {}
   }
   
   int somma_di = 0;
   foreach (char l in disp)
   {
    string lettera = l.ToString();
     
    using (StreamReader sr = File.OpenText(path))
    {
     string s = " ";
     
     while ((s = sr.ReadLine()) != null)
     {
      com = com.ToUpper();
      string[] riga = s.Split(',');
      
      
      string l_disp = riga[0];
      string v_disp = riga[1];
      
      int val_disp = Int32.Parse(v_disp);
      
      if (lettera == l_disp)
      {
       somma_di = somma_di + val_disp;
      }
     }
     
    }
   }
   

   
   path = @"resto.txt";
   int tot;
   int tot_somma;
   
   tot_somma = somma_di + somma_pa;
   tot = tot_somma % 26;
   string totale = tot.ToString();
   
   
   using (StreamReader sr = File.OpenText(path))
   {
    string s = " ";
     
    while ((s = sr.ReadLine()) != null)
    {
     string[] riga = s.Split(',');
      
      
     string l_tot = riga[0];
     string v_tot = riga[1];
     
     if (totale == l_tot)
     {
      label8.Text += v_tot;
     }
    }
     
   }
   string mese_nasc="";
   switch(label8.Text[8])
   {
   	case 'A':
   		mese_nasc = "Gennaio";
   		break;
   	case 'B':
   		mese_nasc = "Febbraio";
   		break;
   	case 'C':
   		mese_nasc = "Marzo";
   		break;
   	case 'D':
   		mese_nasc = "Aprile";
   		break;
   	case 'E':
   		mese_nasc = "Maggio";
   		break;
   	case 'H':
   		mese_nasc = "Giugno";
   		break;
   	case 'L':
   		mese_nasc = "Luglio";
   		break;
   	case 'M':
   		mese_nasc = "Agosto";
   		break;
   	case 'P':
   		mese_nasc = "Settembre";
   		break;
   	case 'R':
   		mese_nasc = "Ottobre";
   		break;
   	case 'S':
   		mese_nasc = "Novembre";
   		break;
   	case 'T':
   		mese_nasc = "Dicembre";
   		break;
   }
   int giorno_s = Convert.ToInt32(label8.Text[9]);
   int giorno_uff=0;
   string sesso_cod="";
   if(giorno_s == 48)
   {
   	 giorno_uff = 0;
   }
   else if(giorno_s == 49)
   {
   	 giorno_uff = 1;
   }
   else if(giorno_s == 50)
   {
   	giorno_uff = 2;
   }
   else if(giorno_s == 51)
   {
   	giorno_uff = 3;
   }
   else if(giorno_s == 52)
   {
   	giorno_uff = 4;
   }
   else if(giorno_s == 53)
   {
   	giorno_uff = 5;
   }
   else if(giorno_s == 54)
   {
   	giorno_uff = 6;
   }
   else if(giorno_s == 55)
   {
   	giorno_uff = 7;
   }
   if(giorno_uff >= 0 && giorno_uff <= 3)
   {
   	sesso_cod = "Maschio";

   }
   else
   {
   	sesso_cod = "Femmina";
   }
   MessageBox.Show("cognome: " + label8.Text[0] + label8.Text[1] + label8.Text[2] + " nome: " + label8.Text[3] + label8.Text[4] + label8.Text[5] + " anno nascita: " + label8.Text[6] + label8.Text[7] + " mese di nascita: " + mese_nasc + " giorno di nascita: " + giorno_uff + label8.Text[10] + " sesso: " + sesso_cod + " carattere di controllo: " + label8.Text[15], "dati personali", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		
		void Button2Click(object sender, EventArgs e)
		{
			 this.Close();
		}
		
		
		
		void TextBox4TextChanged(object sender, EventArgs e)
		{
			string nome = textBox4.Text;
			bool c_nome = false;
			foreach (char carattere in nome) 
			{
			
				if ("0123456789<>|!£$%&/()='?ì^[éè{+*]}òç@à°#.:,;-_ù§\"".Contains(carattere.ToString()))
				{
					c_nome = true;
				}
				
			}
			if (c_nome == true)
			{
				MessageBox.Show("Errore nell'inserimento del nome", "errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				textBox4.Text = "";
				
			}
		}
		
		void TextBox5TextChanged(object sender, EventArgs e)
		{
			string cognome = textBox5.Text;
			bool c_cognome = false;
			foreach (char carattere in cognome)
			{
			
				if ("0123456789<>|!£$%&/()='?ì^[éè{+*]}òç@à°#.:,;-_ù§\"".Contains(carattere.ToString()))
				{
					c_cognome = true;
				}
				
			}
			if (c_cognome == true)
			{
				MessageBox.Show("Errore nell'inserimento del cognome", "errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				textBox5.Text = "";
			}
		}
		
		void TextBox6TextChanged(object sender, EventArgs e)
		{
			string comune = textBox6.Text;
			bool c_comune = false;
			
			foreach (char carattere in comune)
			{
			
				if ("0123456789<>|!£$%&/()='?ì^[éè{+*]}òç@à°#.:,;-_ù§\"".Contains(carattere.ToString()))
				{
					c_comune = true;
				}
				
			}
			if (c_comune == true)
			{
				MessageBox.Show("Errore nell'inserimento del comune di nascita", "errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
				textBox6.Text = "";
			}
		}

	}
}
